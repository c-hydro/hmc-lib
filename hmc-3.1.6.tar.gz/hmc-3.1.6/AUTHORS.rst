==========
Developers
==========

* Fabio Delogu <fabio.delogu@cimafoundation.org>
* Simone Gabellani <simone.gabellani@cimafoundation.org>
* Francesco Silvestro <francesco.silvestro@cimafoundation.org>
* Valerio Basso <>
* Andrea Libertino <andrea.libertino@cimafoundation.org>
* Giulia Ercolani <giulia.ercolani@cimafoundation.org>
